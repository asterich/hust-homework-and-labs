#ifndef GOMOKU_DRAW_H
#define GOMOKU_DRAW_H

#include "../common/common.h"
#include <stdio.h>

#include "gomoku.h"

// sizes of widgets
#define BOARD_NUM 12

#define OUTER_GRID_SIZE 40
#define CHESS_SIZE 30

#define BOARD_X 30
#define BOARD_Y 30

#define START_BUTTON_WIDTH 150
#define START_BUTTON_HEIGHT 60
#define START_BUTTON_X 708
#define START_BUTTON_Y 150


#define RESTART_BUTTON_WIDTH 150
#define RESTART_BUTTON_HEIGHT 60
#define RESTART_BUTTON_X 708
#define RESTART_BUTTON_Y 250

// color
#define RED FB_COLOR(255, 0, 0)
#define ORANGE FB_COLOR(255, 165, 0)
#define YELLOW FB_COLOR(255, 255, 0)
#define GREEN FB_COLOR(0, 255, 0)
#define CYAN FB_COLOR(0, 127, 255)
#define BLUE FB_COLOR(0, 0, 255)
#define PURPLE FB_COLOR(139, 0, 255)
#define WHITE FB_COLOR(255, 255, 255)
#define BLACK FB_COLOR(0, 0, 0)

#define COLOR_BACKGROUND WHITE
#define COLOR_GRID BLACK

void draw_board();
void draw_chess(int chess_x, int chess_y, chess_t chess);
void draw_button(int x, int y, int width, int height, int bgcolor, int fontcolor, char *text);
void draw_button_pressed(int x, int y, int width, int height, int bgcolor, int fontcolor, char *text);
void draw_text(int x, int y, int font_size, int color, char *text);
void update();

#endif