#include "gomoku_draw.h"

void draw_board() {
  fb_draw_rect(BOARD_X, BOARD_Y, BOARD_SIZE * OUTER_GRID_SIZE,
               BOARD_SIZE * OUTER_GRID_SIZE, BLUE);
  for (int x = BOARD_X + OUTER_GRID_SIZE / 2;
       x < BOARD_X + BOARD_SIZE * OUTER_GRID_SIZE; x += OUTER_GRID_SIZE) {
    fb_draw_line(x, BOARD_Y + OUTER_GRID_SIZE / 2, x,
                 BOARD_Y + BOARD_SIZE * OUTER_GRID_SIZE - OUTER_GRID_SIZE / 2,
                 COLOR_GRID);
  }
  for (int y = BOARD_Y + OUTER_GRID_SIZE / 2;
       y < BOARD_Y + BOARD_SIZE * OUTER_GRID_SIZE; y += OUTER_GRID_SIZE) {
    fb_draw_line(BOARD_X + OUTER_GRID_SIZE / 2, y,
                 BOARD_X + BOARD_SIZE * OUTER_GRID_SIZE - OUTER_GRID_SIZE / 2,
                 y, COLOR_GRID);
  }
  return;
}

void draw_chess(int chess_x, int chess_y, chess_t chess) {
  if (chess == NO_CHESS)
    return;
  if (chess_x < 0 || chess_x >= BOARD_SIZE || chess_y < 0 ||
      chess_y >= BOARD_SIZE)
    return;
  int color = (chess == BLACK_CHESS) ? BLACK : WHITE;
  fb_draw_circle(BOARD_X + OUTER_GRID_SIZE / 2 + chess_x * OUTER_GRID_SIZE,
                 BOARD_Y + OUTER_GRID_SIZE / 2 + chess_y * OUTER_GRID_SIZE,
                 CHESS_SIZE / 2, color);
  return;
}

void draw_button(int x, int y, int width, int height, int bgcolor,
                 int fontcolor, char *text) {
  fb_draw_rect(x, y, width, height, bgcolor);
  fb_draw_border(x, y, width, height, BLACK);
  int font_size = 20;
  fb_draw_text(x + width / 2 - strlen(text) * font_size / 2 / 2, y + height / 2,
               text, font_size, fontcolor);
  return;
}

void draw_button_pressed(int x, int y, int width, int height, int bgcolor,
                         int fontcolor, char *text) {
  int deeper_bgcolor = (char)(bgcolor >> 16) / 2 << 16 |
                       (char)(bgcolor >> 8) / 2 << 8 | (char)(bgcolor) / 2;
  fb_draw_rect(x, y, width, height, deeper_bgcolor);
  fb_draw_rect(x + 5, y + 5, width - 6, height - 6, bgcolor);
  fb_draw_border(x, y, width, height, BLACK);
  int font_size = 20;
  fb_draw_text(x + width / 2 - strlen(text) * font_size / 2 / 2 + 5,
               y + height / 2 + 5, text, font_size, fontcolor);
  return;
}

void draw_text(int x, int y, int font_size, int color, char *text) {
  fb_draw_text(x, y, text, font_size, color);
  return;
}

void update() { fb_update(); }